package com.example.demo.service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	public Product addProduct(Product product) {
		return productRepository.save(product);
	}

	public Optional<Product> findProductById(Long id) {
		return productRepository.findById(id);
	}

	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	public Product updateProduct(Long id, Product productDetails) {
		return productRepository.findById(id)
				.map(product -> {
					product.setName(productDetails.getName());
					product.setPrice(productDetails.getPrice());
					product.setActive(productDetails.isActive());
					return productRepository.save(product);
				})
				.orElseGet(() -> {
					productDetails.setId(id);
					return productRepository.save(productDetails);
				});
	}
}
